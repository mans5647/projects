a = int(input("Enter number : ")) # get number from stdin
if a > 0: # checking for positive value
    a = a + 1 # if positive, adding 1 
    print("Number :", a, " = positive") # putting number to stdout
else: # if number is less or equal to 0
    print("Number is less or equal to 0, so hasn't been changed") # message about action abortion
    print("Num : ", a) # printing a 

